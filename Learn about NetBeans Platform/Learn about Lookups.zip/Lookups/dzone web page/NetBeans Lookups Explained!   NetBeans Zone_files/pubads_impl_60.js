<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
 <HEAD>
  <TITLE>Доступ Запрещен</TITLE>
  <META NAME="Generator" CONTENT="Bloknot!!!">
  <meta http-equiv="Content-Type" content="text/html; charset=utf8">
 </HEAD>

 <BODY><BR><BR>
 <CENTER><IMG SRC="http://172.16.0.3/access-denied.png" WIDTH="256" HEIGHT="256" BORDER="0" ALT=""></CENTER>
<CENTER><BR>Доступ к этому сайту запрещен!</CENTER><BR>
 </BODY>
</HTML>
